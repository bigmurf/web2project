<?php  
  $fexa_banner= '';
  $fexa_header_style= '';
  global $post,$fexa;

  //$fexa_hdr_btn = (!empty($fexa['hdr_btn'])) ? $fexa['hdr_btn'] : esc_html('Free Quote','fexa'); 
  //$fexa_hdr_btn_url = (!empty($fexa['hdr_btn_url'])) ? $fexa['hdr_btn_url'] : '';

  if(is_page()){  
    $fexa_header  = get_post_meta($post->ID,'_theme_core_header_style',true);
    $fexa_header_style = (isset($fexa_header)) ? $fexa_header : '0';
    $fexa_banner = (get_post_meta($post->ID,'_theme_core_banner_style',true)) ? get_post_meta($post->ID,'_theme_core_banner_style',true) : '0'; 

  }else{  
    if((is_home() && is_front_page()) || is_home()){
      $fexa_banner =  (!empty($fexa['banner_switchs'])) ? $fexa['banner_switchs'] : '0';
    }else if(is_single()){
      if(is_singular('tc_cases')){
        $fexa_banner =  (!empty($fexa['case_banner_switchs'])) ? $fexa['case_banner_switchs'] : '0';
      }else if(is_singular('tc_attorney')){
        $fexa_banner =  (!empty($fexa['attorney_banner_switchs'])) ? $fexa['attorney_banner_switchs'] : '0';
      }else{
        $fexa_banner =  (!empty($fexa['post_banner_switchs'])) ? $fexa['post_banner_switchs'] : '0';
      }
    }  
    $fexa_header_style = isset($fexa['header_styl']) ? $fexa['header_styl'] : '0';  
  } 
?>
<header class="fame-header <?php echo esc_attr(($fexa_banner!='1') ? 'no-banner' : ''); ?> <?php echo esc_attr(($fexa_header_style=='1') ? 'fame-header--tansparent' : 'no-transparent'); ?>">
  <div class="menu-area">
    <div class="container-fluid">
      <div class="d-flex  align-items-center">
        <div class="logo-wrapper mr-auto">
          <a href="<?php echo esc_url(home_url('/')); ?>" class="logo">
            <img class="default" src="<?php echo esc_url(Fexa::fexa_logo('url')); ?>" alt="<?php echo esc_attr(Fexa::fexa_logo('alt')); ?>">
            <img class="transparent" src="<?php echo esc_url(Fexa::fexa_logo_hover('url')); ?>" alt="<?php echo esc_attr(Fexa::fexa_logo_hover('alt')); ?>">
          </a>
        </div>
        <div class="nav-menu">
          <nav id="easy-menu">
            <?php fexa_main_menu(); ?> 
          </nav> 
        </div>
        <div class="d-flex align-items-center">
          <div class="search-box">
            <a href="#!">
              <svg version="1.1" class="svg-base-width" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" xmlns:xlink="http://www.w3.org/1999/xlink" enable-background="new 0 0 512 512">
                <g>
                  <path d="M495,466.2L377.2,348.4c29.2-35.6,46.8-81.2,46.8-130.9C424,103.5,331.5,11,217.5,11C103.4,11,11,103.5,11,217.5   S103.4,424,217.5,424c49.7,0,95.2-17.5,130.8-46.7L466.1,495c8,8,20.9,8,28.9,0C503,487.1,503,474.1,495,466.2z M217.5,382.9   C126.2,382.9,52,308.7,52,217.5S126.2,52,217.5,52C308.7,52,383,126.3,383,217.5S308.7,382.9,217.5,382.9z"/>
                </g>
              </svg>
            </a> 
            <?php if($fexa_hdr_btn_url): ?>
              <a href="<?php echo esc_url($fexa_hdr_btn_url); ?>" class="hdr-btn <?php echo esc_attr(($fexa_header_style=='1') ? 'trans-header' : ''); ?>"><?php echo esc_html($fexa_hdr_btn); ?></a>
            <?php endif; ?>
            <div class="top-search-input-wrap">
              <span class="close-icon"><i class="icon-icomooon-close"></i></span>
              <div class="top-search-overlay"></div>
              <form action="<?php echo esc_url(home_url('/')); ?>" method="get">
                <div class="search-wrap">
                  <div class="search  pull-right educon-top-search">
                    <div class="sp_search_input"> 
                      <input maxlength="200" class="pull-right" type="text" placeholder="<?php echo esc_attr( 'Search', 'fexa' ); ?>" value="<?php echo get_search_query(); ?>" name="s"> 
                      <input type="submit" class="sp_search_submit"> 
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <!--/.search-box -->
          <a href="#" class="d-xl-none d-lg-none ml-3 bar-menu" id="humbarger-icon"><i class="fa fa-bars"></i></a>
        </div>
      </div>
    </div>
  </div>
  <nav class="mobile-background-nav">
    <div class="mobile-inner">
      <span class="mobile-menu-close"><i class="icon-icomooon-close"></i></span>
      <?php fexa_mobile_menu(); ?> 
    </div>
  </nav>
</header> 