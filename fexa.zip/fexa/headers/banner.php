<?php 
/**
 * The template for displaying header banner
 * 
 * @package Fexa
 */  
global $post,$fexa;
if(is_page()){  
  $fexa_banner_title = trim(get_post_meta($post->ID,'_theme_core_banner_title',true)); 
  $fexa_banner_title = (''!=$fexa_banner_title) ? $fexa_banner_title : get_the_title(); 
}else{     
  $fexa_banner_title = fexa_banner_title();     
} 
?>
<div class="banner-area banner-area--blog">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h2 class="page-title red-separator text-center white-text"><?php echo esc_html($fexa_banner_title); ?></h2>
      </div>
    </div>
  </div>
</div> 