<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fexa
 */ 
get_header(); ?>
 
<div class="main-content section-padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-lg-8">
        <?php 
          /* Start the Loop */
          if ( have_posts() ) :
            while ( have_posts() ) : the_post(); 
              get_template_part( 'template-parts/content' );   
            endwhile; 
          else: 
            get_template_part( 'template-parts/content','none' ); 
          endif; 
        ?>   
        <!--/.blog-post2-->
        <div class="text-center mb20">
          <?php fexa_pagination(); ?> 
        </div>
      </div>
      <div class="col-md-12 col-lg-4">
        <aside class="sidebar">
          <?php get_sidebar(); ?>
        </aside>
      </div>
    </div>
  </div>
</div> 
<?php get_footer();
