<?php 
/**
 * The template for displaying footer style 1
 * 
 * @package Fexa
 */ 
global $post,$fexa;
$fexa_call2_text = (!empty($fexa['cal2_text'])) ? $fexa['cal2_text'] : '';
$fexa_call2_btn = (!empty($fexa['cal2_btn'])) ? $fexa['cal2_btn'] : '';
$fexa_call2_btn_lnk = (!empty($fexa['cal2_btn_lnk'])) ? $fexa['cal2_btn_lnk'] : ''; 
?>
<?php if($fexa_call2_text && $fexa_call2_btn): ?>
  <div class="looking-expert-area">
    <div class="container">
      <div class="d-sm-flex justify-content-between align-items-center">
        <h3 class="looking-expert-title white-text heading-lavel-3"><?php echo esc_html($fexa_call2_text); ?></h3>
        <?php if($fexa_call2_btn_lnk): ?>
          <div class="">
            <a href="<?php echo esc_url($fexa_call2_btn_lnk); ?>" class="btn base-bg"><?php echo esc_html($fexa_call2_btn); ?></a>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
<?php endif; ?>

<footer class="harry-footer">
  <div class="container"> 
    <?php if ( is_active_sidebar( 'footer-wgt' ) ) {
      echo '<div class="row">';
      dynamic_sidebar( 'footer-wgt' );
      echo '</div>';
    } ?>
    <div class="row">
      <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center footer-bottom mb10 <?php echo (!is_active_sidebar( 'footer-wgt' )) ? 'nowdgt' : ''; ?>">
          <?php $fexa_social = !empty($fexa['copyright_social']['Enabled']) ? $fexa['copyright_social']['Enabled'] : ''; 
          $fexa_social_true = 0;
          if($fexa_social):
            $fexa_social_true = 1;
          ?>
            <ul class="social-icons all-text-white"> 
              <?php  
              foreach ($fexa_social as $key=>$value) {
                switch ($key) {
                  case 'facebook':  
                    Fexa::fexa_social_links('facebook','blank');
                    break;
                  
                  case 'twitter': 
                    Fexa::fexa_social_links('twitter','blank');
                    break;
                  
                  case 'google_plus': 
                    Fexa::fexa_social_links('google-plus','blank');
                    break;
                  
                  case 'linkedin': 
                    Fexa::fexa_social_links('linkedin','blank');
                    break;
                  
                  case 'pinterest': 
                    Fexa::fexa_social_links('pinterest','blank');
                    break;
                  
                  case 'instagram': 
                    Fexa::fexa_social_links('instagram','blank');
                    break; 

                  default:
                    # code...
                    break;
                }
              }
              ?> 
            </ul>
          <?php endif; ?>
          <div class="copyright-text white-text <?php echo (!$fexa_social_true) ? 'dflt-copyright' : ''; ?>">
            <?php Fexa::fexa_copyright(); ?>            
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
