<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fexa
 */

get_header(); ?>
<div class="main-content section-padding">
  <div class="container">
    <div class="row">
      <?php if(!is_active_sidebar('sidebar-1')){
        $col = '12';
      }else{
        $col = '8';
      } ?>
      <div class="col-md-12 col-lg-<?php echo esc_attr($col); ?>">
      <h2> <?php the_title() ?> </h2>
      <?php
          /* Start the Loop */
            $homepageCases = new WP_Query(array(
            'posts_per_page' => 5,
            'post_type' => 'news'
            ));
            while($homepageCases->have_posts()){
            $homepageCases->the_post();?>
            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            <p><?php echo wp_trim_words(get_the_content(),50); ?>
            <a href="<?php the_permalink();?>">Learn more</a>
            </p>
            <?php }
            
		?>
        <!--/.blog-post2-->
      </div>
      <?php if(is_active_sidebar('sidebar-1')): ?>
        <div class="col-md-12 col-lg-4">
          <aside class="sidebar">
            <?php get_sidebar(); ?>
          </aside>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php get_footer();
