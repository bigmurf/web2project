<?php 
/**
 * Fexa functions and definitions
 */ 
define('FEXA_NAME', wp_get_theme()->get( 'Name' )); 
define('FEXA_VERSION', wp_get_theme()->get( 'Version' )); 
define('FEXA_DIR', get_template_directory().'/');
define('FEXA_URI', get_template_directory_uri().'/');

/**
 * Fexa functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Fexa
 */

if ( ! function_exists( 'fexa_setup' ) ) :

	function fexa_setup() {

		load_theme_textdomain( 'fexa', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title. 
		 */
		add_theme_support( 'title-tag' ); 

		/*
		 * Image size declaration. 
		 */
		add_image_size('fexa-single-post',1200,800,true); 
		add_image_size('fexa-blog-post',770,510,true); 
		add_image_size('fexa-blog-post-hom',367,244,true); 

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 * 
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'mainmenu' => esc_html__( 'Main Menu', 'fexa' ),
			'mobilemenu' => esc_html__( 'Mobile Menu', 'fexa' ) 
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'fexa_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
 
		/*
		 * This theme styles the visual editor to resemble the theme style,
		 * specifically font, colors, icons, and column width.
		 */
		add_editor_style( array( 'assets/css/editor-style.css', fexa_fonts_url() ) );
		
	}
endif;
add_action( 'after_setup_theme', 'fexa_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function fexa_content_width() { 
	$GLOBALS['content_width'] = apply_filters( 'fexa_content_width', 640 );
}
add_action( 'after_setup_theme', 'fexa_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function fexa_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'fexa' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'fexa' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget__title heading-lavel-4">',
		'after_title'   => '</h3>',
	) ); 
}
add_action( 'widgets_init', 'fexa_widgets_init' );

/**
 * Register custom fonts.
 */
function fexa_fonts_url() {
	$fonts_url = '';
	$fonts     = array();
	$subsets   = 'latin,latin-ext';

	if ( 'off' !== _x( 'on', 'Lora font: on or off', 'fexa' ) ) {
		$fonts[] = 'Lora:400,700,700i,700i';
	}
  
	if ( 'off' !== _x( 'on', 'Open Sans font: on or off', 'fexa' ) ) {
		$fonts[] = 'Open Sans:300,400,600,700,800';
	} 
 
	if ( $fonts ) {
		$fonts_url = add_query_arg( array(
			'family' => urlencode( implode( '|', $fonts ) ),
			'subset' => urlencode( $subsets ),
		), '//fonts.googleapis.com/css' );
	}

	return $fonts_url;
}

/**
 * Enqueue scripts and styles.
 */
function fexa_scripts() {
	global $fexa,$post; 
	$fexa_google_api = !empty($fexa['gmap_api']) ? $fexa['gmap_api'] : '';

	// Add custom fonts, used in the main stylesheet.
	wp_enqueue_style( 'fexa-fonts', fexa_fonts_url(), array(), null );

	// css  
	wp_enqueue_style( 'fexa-vendor', FEXA_URI . 'assets/css/vendor.css' ); 
	wp_enqueue_style( 'fexa-main', FEXA_URI . 'assets/css/main.css' ); 
	wp_enqueue_style( 'fexa-unit', FEXA_URI . 'assets/css/unit.css' );
	wp_enqueue_style( 'fexa-style', get_stylesheet_uri() ); 

	// js 
	if($fexa_google_api){
		wp_enqueue_script( 'fexa-gmap', '//maps.googleapis.com/maps/api/js?key='.$fexa_google_api, array('jquery'), FEXA_VERSION, true );  
	}

	wp_enqueue_script( 'modernizr', FEXA_URI . 'assets/js/modernizr-2.8.3.min.js', array('jquery'), FEXA_VERSION, false );
	wp_enqueue_script( 'bootstrap', FEXA_URI . 'assets/js/bootstrap.min.js', array('jquery'), FEXA_VERSION, true );
	wp_enqueue_script( 'owl-carousel', FEXA_URI . 'assets/js/owl.carousel.min.js', array(), FEXA_VERSION, true );
	wp_enqueue_script( 'wow', FEXA_URI . 'assets/js/wow.min.js', array(), FEXA_VERSION, true );
	wp_enqueue_script( 'mixitup', FEXA_URI . 'assets/js/mixitup.min.js', array(), FEXA_VERSION, true );	   
	wp_enqueue_script( 'jquery-waypoints', FEXA_URI . 'assets/js/jquery.waypoints.min.js', array(), FEXA_VERSION, true );
	wp_enqueue_script( 'jquery-counterup', FEXA_URI . 'assets/js/jquery.counterup.min.js', array(), FEXA_VERSION, true );
	wp_enqueue_script( 'fexa-custom', FEXA_URI . 'assets/js/custom.js', array(), FEXA_VERSION, true );

	wp_enqueue_script( 'fexa-navigation', FEXA_URI . 'assets/js/navigation.js', array(), FEXA_VERSION, true );
	wp_enqueue_script( 'fexa-skip-link-focus-fix', FEXA_URI . 'assets/js/skip-link-focus-fix.js', array(), FEXA_VERSION, true );
 
	// condition between page and defaults
	$custom_css = "";
	$fexa_banner_img = "";
    if(is_page()){ 
    	global $post;
    	$fexa_banner_img = get_post_meta($post->ID,'_theme_core_banner_img',true);
	    if($fexa_banner_img){ 
	        $fexa_banner_img = $fexa_banner_img;
	    }else{
	        $fexa_banner_img = (!empty($fexa['bnr_banner']['url'])) ? ($fexa['bnr_banner']['url']) : (FEXA_URI.'assets/images/blog-banner.jpg');  
	    }
	    
	}else{  
        if((is_home() && is_front_page()) || is_home()){
             $fexa_banner_img = (!empty($fexa['bnr_banner']['url'])) ? ($fexa['bnr_banner']['url']) : (FEXA_URI.'assets/images/blog-banner.jpg');
        }else if(is_single()){
            if(is_singular('tc_cases')){
                $fexa_banner_img = (!empty($fexa['case_bnr_banner']['url'])) ? ($fexa['case_bnr_banner']['url']) : (FEXA_URI.'assets/images/blog-banner.jpg');
            }else if(is_singular('tc_attorney')){
               $fexa_banner_img = (!empty($fexa['attorney_bnr_banner']['url'])) ? ($fexa['attorney_bnr_banner']['url']) : (FEXA_URI.'assets/images/blog-banner.jpg');
            }else{
                $fexa_banner_img = (!empty($fexa['post_bnr_banner']['url'])) ? ($fexa['post_bnr_banner']['url']) : (FEXA_URI.'assets/images/blog-banner.jpg');
            }
        }   
	}
	// banner image
    $custom_css .= "
        .banner-area--blog{
            background-image: url({$fexa_banner_img});
    	}
    "; 
    
	// header shadow
	$fexa_header_bg = (isset($fexa['header_shadow_clr']['rgba']) && !empty($fexa['header_shadow_clr']['rgba'])) ? ($fexa['header_shadow_clr']['rgba']) : 'rgba(0, 0, 0, 0.09)';  
    $custom_css .= "
        .fame-header{
    		box-shadow: 0 1px 2px {$fexa_header_bg};
    	}
    "; 

    // footer  bg image
	$fexa_top_footer_bg_1 = (isset($fexa['top_footer_bg_1'])) ? $fexa['top_footer_bg_1'] : '1'; 
	$top_footer_bg_img_1 = (!empty($fexa['top_footer_bg_img_1']['url'])) ? ($fexa['top_footer_bg_img_1']['url']) : '';
	if(('0'==$fexa_top_footer_bg_1) && (''!=$top_footer_bg_img_1)){
	    $custom_css .= "
	        footer.harry-footer{
	            background-image: url({$top_footer_bg_img_1});
	    	}
	    ";
	} 
     
    wp_add_inline_style( 'fexa-style', $custom_css );

 	// localize script
	$localization = array(
		'ajaxurl' => admin_url('admin-ajax.php'),
		'homeUrl' => esc_url(home_url('/')),
		'dir' => esc_url(get_template_directory_uri()),
		'added' => esc_html__('Added','fexa'),
		'wadded' => esc_html__('Added To Favorite','fexa') 
	); 
	if ( class_exists( 'WooCommerce' ) ) {
		$localization['single_p'] = is_product();
	}
	wp_localize_script( 'fexa-custom', 'admin_ajaxurl', $localization ); 
	wp_localize_script( 'fexa-mapinit', 'admin_ajaxurl', $localization ); 
		 

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'fexa_scripts' );
 
/**
 * Excerpt lenght.
 */
function fexa_excerpt_length( $length ) {
	if(has_post_thumbnail()){
    	return 35;
	}else{
    	return 38;	
	}
}
add_filter( 'excerpt_length', 'fexa_excerpt_length', 999 );

/**
 * Excerpt More.
 */
function fexa_excerpt_more( $more ) {
	return '...';
}
add_filter('excerpt_more', 'fexa_excerpt_more');


/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Fexa functions.
 */
require get_template_directory() . '/inc/own/custom-functions.php'; 
require get_template_directory() . '/inc/own/breadcrumb.php';
require get_template_directory() . '/inc/own/option-functions.php';
require get_template_directory() . '/inc/own/required-plugins.php';  

