
<div id="searchbox" class="show"> 
    <form method="get" class="searchform" action="<?php echo esc_url(home_url('/')); ?>"> 
		<input type="search"  id="search-input" placeholder="<?php esc_attr_e( 'Search...', 'fexa' ); ?>" value="<?php echo get_search_query(); ?>" name="s"> 
		<button type="submit"><i class="fa fa-search"></i></button>
	</form> 
</div>