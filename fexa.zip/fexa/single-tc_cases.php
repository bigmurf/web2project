<?php
/**
 * The template for displaying all single cases
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Fexa
 */ 
get_header();
?> 
	<div class="container "> 	
		<?php 
			/* Start the Loop */
			while ( have_posts() ) : the_post(); 
				the_content();
			endwhile; 
		?>  
	</div>  
<?php get_footer();
