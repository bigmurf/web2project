<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fexa
 */
get_header(); ?>

<div class="main-content section-padding">
  <div class="container">
    <div class="row">
      <?php if(!is_active_sidebar('sidebar-1')){
        $col = '12';
      }else{
        $col = '8';
      } ?>
      <div class="col-md-12 col-lg-<?php echo esc_attr($col); ?>"> 
        <?php 
          /* Start the Loop */
          if ( have_posts() ) :
            while ( have_posts() ) : the_post(); 
              get_template_part( 'template-parts/content' );   
            endwhile; 
          else: 
            get_template_part( 'template-parts/content','none' ); 
          endif; 
        ?>  
        <!--/.blog-post2-->
        <div class="text-center mb20 fexa-pagination">
          <?php fexa_pagination(); ?> 
        </div>
      </div>
      <?php if(is_active_sidebar('sidebar-1')): ?>
        <div class="col-md-12 col-lg-4">
          <aside class="sidebar">
            <?php get_sidebar(); ?>
          </aside>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>  
<?php get_footer();  