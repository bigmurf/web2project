<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fexa
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>

<?php
// You can start editing here -- including this comment!
if ( have_comments() ) :
	?>
	<div class="blog_comments_box"> 
			<h2>
				<?php
				$fexa_comment_count = get_comments_number();
				if ( '1' === $fexa_comment_count ) {
					printf(
						/* translators: 1: title. */
						esc_html__( 'Comment (%1$s)', 'fexa' ), 
						'<span>' . 1 . '</span>'
					);
				} else {
					printf( // WPCS: XSS OK.
						/* translators: 1: comment count number, 2: title. */
						esc_html( _nx( 'Comments (%1$s)','Comments (%1$s)', $fexa_comment_count, 'comments title', 'fexa' ) ), 
						number_format_i18n( $fexa_comment_count ) 
					);
				}
				?>
			</h2><!-- .comments-title -->

			<?php the_comments_navigation(); ?>
	 		<div class="comment-list">
				<?php
					wp_list_comments( array(
						'style'      => 'ul',
						'callback' => 'fexa_comments_list' 
					) );
				?> 
			</div>
			<?php
			the_comments_navigation();

			// If comments are closed and there are comments, let's leave a little note, shall we?
			if ( ! comments_open() ) :
				?>
				<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'fexa' ); ?></p>
				<?php
			endif; ?>
	</div>
<?php endif; // Check for have_comments(). ?>
<div class="mt35 pdt20 pdb20">
	<?php comment_form(); ?>
</div>
