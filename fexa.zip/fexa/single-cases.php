<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Fexa
 */ 
get_header(); ?>
<div class="main-content section-padding">
  <div class="container pdt10">
    <div class="row">
      <?php if(!is_active_sidebar('sidebar-1')){
        $col = '12';
      }else{
        $col = '8';
      } ?>
      <div class="col-lg-<?php echo esc_attr($col); ?> col-md-12">
    		<?php while ( have_posts() ) : 
        ?>
        <h2> <?php the_title(); ?> </h2>
        <?php
        the_post();
        the_content();
    		endwhile; ?>
      </div>
      <?php if(is_active_sidebar('sidebar-1')): ?>
        <div class="col-lg-4 col-md-12">
          <aside class="sidebar">
            <?php get_sidebar(); ?>
          </aside>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php 
get_footer();