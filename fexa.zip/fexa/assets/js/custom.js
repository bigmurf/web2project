 (function ($) {
    'use strict';
 

  //  menu position moved if no space to right side
  $('#fexa-main-menu li').hover(function(){ 
    if($(this).children('ul').length){
      var of = $(this).children('ul').offset(), // this will return the left and top
        left = of.left, // this will return left 
        right = $(window).width() - left - $(this).children('ul').width(), // you can get right by calculate
        width = $(this).children('ul').width()+50;
           
      if(right > width ){
        $(this).children('ul').find('ul').css('margin-left', '90%'); 
      }else{
        $(this).children('ul').find('ul').css({'margin-left':'0','right':'100%'}); 
      }
    }
  });

  /** ===== Preloder ========**/
  $(document).ready(function(){
    $('.preloader').fadeOut();
  });

  /** ===== Menu ========**/
  $('#fexa-main-menu ul.sub-menu,#fexa-mobile-menu ul.sub-menu').addClass('dropdown'); 
  $('#fexa-main-menu li.menu-item-has-children > a, #fexa-mobile-menu li.menu-item-has-children > a').append('<i class="fa fa-angle-down"></i>'); 

 
  /* ========================================== 
    Sticky Menu
  ========================================== */

  $(window).scroll(function(){
    if ($(window).scrollTop() >= 1) {
      $('.fame-header').addClass('sticky'); 
      $('.fame-header--tansparent .hdr-btn').removeClass('trans-header'); 
    }
    else {
      $('.fame-header').removeClass('sticky'); 
      $('.fame-header--tansparent .hdr-btn').addClass('trans-header'); 
    }
  });



  /*** =====================================
  * 	Mobile Menu
  * =====================================***/
	$('.mobile-background-nav a .fa').on('click',function(e) {
  	e.preventDefault();
    var $this = $(this).parent();
    if ($this.next().hasClass('menu-show')) {
      $this.next().removeClass('menu-show');
      $this.next().slideUp(350);
    } else {
      $this.parent().parent().find('li .dropdown').removeClass('menu-show');
      $this.parent().parent().find('li .dropdown').slideUp(350);
      $this.next().toggleClass('menu-show');
      $this.next().slideToggle(350);
    }
	});
	$('.mobile-menu-close i').on('click',function(){
	  $('.mobile-background-nav').removeClass('in');
	});

	$('#humbarger-icon').on('click',function(e){
    e.preventDefault();
	  $('.mobile-background-nav').toggleClass('in');
	});

  /**=====================================
  *  MixitUp Carousel
  * =====================================*/   
  if( $('#grid-vc').length){
    $('#grid-vc').mixItUp();
  }

  /**=====================================
  *  Testimonial Carousel
  * =====================================*/
 
    $('.testimonial-carousel-vc').owlCarousel({
      items:2,
      autoplay:false,
      dots: true,
      loop:true,
      nav:false,
      margin:30,
      responsive:{
        0:{
          items:1,
        },
        480:{
          items:1,
        },
        768:{
          items:1,
        }
      }
    });
          

  /**=====================================
  *  Client Carousel
  * =====================================*/
  $('.client-carousel-vc').owlCarousel({
    items:6,
    autoplay:true,
    dots: false,
    loop:true,
    nav:false,
    margin:30,
    responsive:{
      0:{
        items:3,
      },
      480:{
        items:4,
      },
      768:{
        items:6,
      }
    }
  });

  /**
  * =====================================
  * Main Menu fixed
  * =====================================
  */
  if( $('.fame-header--tansparent').length){
    var $navberArea=$('.fame-header--tansparent');
    $(window).on('scroll', function() {
      if ($(this).scrollTop() > 1) {
        $navberArea.addClass("main-menu-fix");
      }
      else {
        $navberArea.removeClass("main-menu-fix");
      }
    });
  }


  /** =====================================
  *  Wow JS
  * ===================================== **/
  if($('.wow').length){
    var wow=new WOW( {
      boxClass: 'wow', // animated element css class (default is wow)
      animateClass: 'animated', // animation css class (default is animated)
      offset: 0, // distance to the element when triggering the animation (default is 0)
      mobile: false, // trigger animations on mobile devices (default is true)
      live: true, // act on asynchronously loaded content (default is true)
      callback: function(box) {}, 
      scrollContainer: true // optional scroll container selector, otherwise use window
    });
    wow.init();
  }

  /*** =====================================
  * Easy Menu
  * =====================================***/
  (function($) {
    $.fn.menumaker = function(options) {
      var cssmenu = $(this),
      settings = $.extend({
        format: "dropdown",
        sticky: false
      }, options);
      return this.each(function() {
        $(this).find(".button").on('click', function() {
          $(this).toggleClass('menu-opened');
          var mainmenu = $(this).next('ul');
          if (mainmenu.hasClass('open')) {
            mainmenu.slideToggle().removeClass('open');
          } else {
            mainmenu.slideToggle().addClass('open');
            if (settings.format === "dropdown") {
              mainmenu.find('ul').show();
            }
          }
        });
        cssmenu.find('li ul').parent().addClass('has-sub');
        var multiTg;
        multiTg = function() {
          cssmenu.find(".has-sub").prepend('<span class="submenu-button"></span>');
          cssmenu.find('.submenu-button').on('click', function() {
            $(this).toggleClass('submenu-opened');
            if ($(this).siblings('ul').hasClass('open')) {
              $(this).siblings('ul').removeClass('open').slideToggle();
            } else {
              $(this).siblings('ul').addClass('open').slideToggle();
            }
          });
        };
        if (settings.format === 'multitoggle') multiTg();
        else cssmenu.addClass('dropdown');
        if (settings.sticky === true) cssmenu.css('position', 'fixed');
        var resizeFix;
        resizeFix = function() {
          var mediasize = 1000;
          if ($(window).width() > mediasize) {
            cssmenu.find('ul').show();
          }
          if ($(window).width() <= mediasize) {
            cssmenu.find('ul').hide().removeClass('open');
          }
        };
        resizeFix();
        return $(window).on('resize', resizeFix);
      });
    };
  })(jQuery);

  $("#easy-menu").menumaker({
    format: "multitoggle"
  });
  
  /** =====================================
  * Counter
  * =====================================***/
  if( $('.counter-active-number').length){
    $('.counter-active-number').counterUp({
      delay: 10,
      time: 3000
    });
  }
  if( $('.progress-number-active').length){
    $('.progress-number-active').counterUp({
      delay: 10,
      time: 1500
    });
  }

  /*** =====================================
  * Progress
  * ==================================== ***/
  jQuery(window).on('scroll', function() {
    var windowHeight = $(window).height();
    function kalProgress() {
      var progress = $('.progress-rate');
      var len = progress.length;
      for (var i = 0; i < len; i++) {
        var progressId = '#' + progress[i].id;
        var dataValue = $(progressId).attr('data-value');
        $(progressId).css({'width':dataValue+'%'});
      }
    }
    var progressRateClass = $('#progress-running');
    if ((progressRateClass).length) {
      var progressOffset = $("#progress-running").offset().top - windowHeight;
      if ($(window).scrollTop() > progressOffset) {
        kalProgress();
      }
    }
  });

  /** =====================================
  *   Search Box
  * =====================================**/
  $('.search-box a').on('click', function(e) {
    e.preventDefault();
    $('.top-search-input-wrap').addClass('show');
  });
  $(".top-search-input-wrap .top-search-overlay, .top-search-input-wrap .close-icon").on('click', function(){
    $('.top-search-input-wrap').removeClass('show');
  });

  /** =====================================
  *  Material input
  * =====================================**/
  $('.form-group--material .form-control').on('focus', function(){
    $(this).siblings('label').addClass('heilight');
  });
  $('.form-group--material .form-control').on('focusout', function(){
    $(this).siblings('label').removeClass('heilight');
  });
  $('.form-group--material .form-control').on('change', function(){
    if($(this).val().length>=1){
      $(this).siblings('label').addClass('heilight-active');
    }
    else{
      $(this).siblings('label').removeClass('heilight-active');
    }
  });


})(jQuery);
 