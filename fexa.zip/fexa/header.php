<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Fexa
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    <?php global $post,$fexa; $fexa_loader = (isset($fexa['preloader']) ? $fexa['preloader'] : '1' ); ?>
    <?php if($fexa_loader== '1'): ?>
        <div class="preloader">
          <div class="loader-inner ball-scale-multiple">
            <img src="<?php echo FEXA_URI; ?>assets/images/logo4.jpg" alt="<?php esc_attr_e('Preloader','fexa'); ?>">
          </div>
        </div>  
    <?php endif; ?>
    <?php 
        global $post,$fexa; 
        // Header style
        if(is_page()){  
            $xhdr = get_post_meta($post->ID,'_theme_core_header_style',true);
            $fexa_header = ($xhdr) ? $xhdr : Fexa::fexa_headers_style();
        }else{
            $fexa_header = Fexa::fexa_headers_style();
        }   
        
        // banner  
        $fexa_banner= '';
        if(is_page()){  
            $fexa_header_style = (get_post_meta($post->ID,'_theme_core_header_style',true)) ? get_post_meta($post->ID,'_theme_core_header_style',true) : '0';
            $fexa_banner = (get_post_meta($post->ID,'_theme_core_banner_style',true)) ? get_post_meta($post->ID,'_theme_core_banner_style',true) : '0';
        }else{  
            if((is_home() && is_front_page()) || is_home()){
                $fexa_banner =  (!empty($fexa['banner_switchs'])) ? $fexa['banner_switchs'] : '0';
            }else if(is_single()){
                if(is_singular('tc_cases')){
                    $fexa_banner =  (!empty($fexa['case_banner_switchs'])) ? $fexa['case_banner_switchs'] : '0';
                }else if(is_singular('tc_attorney')){
                    $fexa_banner =  (!empty($fexa['attorney_banner_switchs'])) ? $fexa['attorney_banner_switchs'] : '0';
                }else{
                    $fexa_banner =  (!empty($fexa['post_banner_switchs'])) ? $fexa['post_banner_switchs'] : '0';
                }
            }  
        } 
        
        get_template_part('headers/header',$fexa_header);

        if($fexa_banner==1){
            get_template_part('headers/banner');
        }
    ?>
 