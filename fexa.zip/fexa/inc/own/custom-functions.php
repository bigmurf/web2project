<?php 

/**=====================================================================
 *  Off Reidrect to Redux welcome
 =====================================================================*/
add_action( 'redux/construct', 'fexa_redux_remove_as_plugin_flag' );
function fexa_redux_remove_as_plugin_flag() {
    ReduxFramework::$_as_plugin = false;
}

/**=====================================================================
 *  Pagination
 =====================================================================*/
if ( ! function_exists( 'fexa_pagination' ) ){ 
	function fexa_pagination($numpages = '', $pagerange = '', $cpaged='',$next='',$prev='') {
		if (empty($pagerange)) {
			$pagerange = 2;
		}
		global $cpaged;
		if (empty($cpaged)) {
			$cpaged = 1;
		}
		if ($numpages == '') {
			global $wp_query;
			$numpages = $wp_query->max_num_pages;
			if(!$numpages) {
			    $numpages = 1;
			}
		}
		if($next==''){
			$next = esc_html('NEXT','fexa');
		}
		if($prev==''){
			$prev = esc_html('PREV','fexa');
		}

		$cpaged        = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
		$pagenum_link = html_entity_decode( get_pagenum_link() );
		$query_args   = array();
		$url_parts    = explode( '?', $pagenum_link );
		if ( isset( $url_parts[1] ) ) {
			wp_parse_str( $url_parts[1], $query_args );
		}
		$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
		$pagenum_link = trailingslashit( $pagenum_link ) . '%_%';
		$format  = $GLOBALS['wp_rewrite']->using_index_permalinks() && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
		$format .= $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit( 'page/%#%', 'paged' ) : '?paged=%#%';
	  	$pagination_args = array(
			'base'      => $pagenum_link,
			'format'    => $format,
			'total'     => $numpages,
			'current'   => $cpaged,
			'mid_size'  => $pagerange,
			'show_all'  => true,
			'add_args'  => array_map( 'urlencode', $query_args ),
			'prev_text' => $prev,
			'next_text' => $next,
			'type'      => 'list',
	  	);
	  	$paginate_links = paginate_links($pagination_args);
	  	if ($paginate_links) { 
	  		echo wp_kses($paginate_links,
	  			array(
	  				'ul'=> array('class'=>array()),
	  				'li'=> array('class'=>array()),
	  				'span'=> array('class'=>array()),
	  				'i'=> array('class'=>array()),
                    'a' => array(
                        'target' => array(),
                        'href' => array(),
                        'title' => array(),
                        'class' => array()
                    ),
	  			)
	  		); 
	  	} 
	}
}
 
/**=====================================================================
 * sidebar post count html append
 =====================================================================*/
function fexa_categories_archive_postcount_filter ($variable) {
	$variable = str_replace('(', '<span class="float-right">(', $variable);
 	$variable = str_replace(')', ')</span>', $variable);
    return $variable;
}
add_filter('wp_list_categories','fexa_categories_archive_postcount_filter');
add_filter('get_archives_link','fexa_categories_archive_postcount_filter');

/**=====================================================================
 * modify archive title
 =====================================================================*/
add_filter( 'get_the_archive_title', function ( $title ) {
	if ( is_category() ) {
        /* translators: Category archive title. 1: Category name */
        $title = sprintf( esc_html( 'Category- %s','fexa' ), single_cat_title( '', false ) );
    } elseif ( is_tag() ) {
        /* translators: Tag archive title. 1: Tag name */
        $title = sprintf( esc_html( 'Tag- %s','fexa' ), single_tag_title( '', false ) );
    } elseif ( is_author() ) {
        /* translators: Author archive title. 1: Author name */
        $title = sprintf( esc_html( 'Author- %s','fexa' ), '<span class="vcard">' . get_the_author() . '</span>' );
    } elseif ( is_year() ) {
        /* translators: Yearly archive title. 1: Year */
        $title = sprintf( esc_html( 'Year- %s','fexa' ), get_the_date( _x( 'Y', 'yearly archives date format','fexa' ) ) );
    } elseif ( is_month() ) {
        /* translators: Monthly archive title. 1: Month name and year */
        $title = sprintf( esc_html( 'Month- %s','fexa' ), get_the_date( _x( 'F Y', 'monthly archives date format','fexa' ) ) );
    } elseif ( is_day() ) {
        /* translators: Daily archive title. 1: Date */
        $title = sprintf( esc_html( 'Day- %s','fexa' ), get_the_date( _x( 'F j, Y', 'daily archives date format' ,'fexa') ) );
    } elseif ( is_tax( 'post_format' ) ) {
        if ( is_tax( 'post_format', 'post-format-aside' ) ) {
            $title = _x( 'Asides', 'post format archive title','fexa' );
        } elseif ( is_tax( 'post_format', 'post-format-gallery' ) ) {
            $title = _x( 'Galleries', 'post format archive title','fexa' );
        } elseif ( is_tax( 'post_format', 'post-format-image' ) ) {
            $title = _x( 'Images', 'post format archive title' ,'fexa');
        } elseif ( is_tax( 'post_format', 'post-format-video' ) ) {
            $title = _x( 'Videos', 'post format archive title','fexa' );
        } elseif ( is_tax( 'post_format', 'post-format-quote' ) ) {
            $title = _x( 'Quotes', 'post format archive title','fexa' );
        } elseif ( is_tax( 'post_format', 'post-format-link' ) ) {
            $title = _x( 'Links', 'post format archive title','fexa' );
        } elseif ( is_tax( 'post_format', 'post-format-status' ) ) {
            $title = _x( 'Statuses', 'post format archive title','fexa' );
        } elseif ( is_tax( 'post_format', 'post-format-audio' ) ) {
            $title = _x( 'Audio', 'post format archive title','fexa' );
        } elseif ( is_tax( 'post_format', 'post-format-chat' ) ) {
            $title = _x( 'Chats', 'post format archive title','fexa' );
        }
    } elseif ( is_post_type_archive() ) {
        /* translators: Post type archive title. 1: Post type name */
        $title = sprintf( esc_html( 'Archives- %s','fexa' ), post_type_archive_title( '', false ) );
    } elseif ( is_tax() ) {
        $tax = get_taxonomy( get_queried_object()->taxonomy );
        /* translators: Taxonomy term archive title. 1: Taxonomy singular name, 2: Current taxonomy term */
        $title = sprintf( esc_html( '%1$s- %2$s','fexa' ), $tax->labels->singular_name, single_term_title( '', false ) );
    } else {
        $title = esc_html( 'Archives','fexa' );
    }
    return $title;
});

/**=====================================================================
 * Comment List 
=====================================================================*/
 
function fexa_comments_list($comment, $args, $depth) { ?>
    <div id="comment-<?php comment_ID() ?>" class="author-info depth-<?php echo esc_attr($depth); ?> <?php if($depth>1){ echo esc_attr('child'); }else{ } ?>">

        <?php  $m0 = 'm0'; if(get_avatar( $comment, 90 )): 
            $m0 = ''; ?>
            <div class="author-info__photo">
                <?php echo get_avatar( $comment, 90 ); ?>
            </div>
        <?php endif; ?> 
        <div class="author-info__text-content <?php echo esc_attr($m0); ?>">
            <h4 class="author-info__name"><?php comment_author(); ?></h4>
            <span class="author-info__date"><?php echo get_comment_date( 'M n, Y, g:i a', $comment ) ; ?></span> 
            <?php comment_text(); ?>
            <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
        </div>
        <div class="clear"></div>
    </div>   
          
<?php } 
 
/**=====================================================================
 *  Comment Form MOdify 
=====================================================================*/
 
function fexa_comment_fields($fields) {

    $fexabutton = '';
    if(is_user_logged_in()){
        $fexabutton = '<button type="submit" class="btn">'.esc_html('Submit','fexa').'</button>';
    } 
	$commenter = wp_get_current_commenter();
	$req = get_option( 'require_name_email' );
	$aria_req = ( $req ? " aria-required='true'" : '' );
    unset($fields['url']);
    $fields['author'] = '<div class="com-box"><div class="form-group form-group--material"><label>'.esc_html('Name','fexa').'</label><input type="text" class="form-control" name="author" value="' . esc_attr( $commenter['comment_author'] ) .
    '"></div>';
    $fields['email'] = '<div class="form-group form-group--material"><label>'.esc_html('Email','fexa').'</label><input type="email" class="form-control" name="email" value="' . esc_attr(  $commenter['comment_author_email'] ) .
    '"></div>';
    $fields['phone'] = '<div class="form-group form-group--material"><label>'.esc_html('Phone','fexa').'</label><input type="text" class="form-control" name="phone" ></div>';
    $fields['url'] = '';
    return $fields;
}
add_filter('comment_form_default_fields','fexa_comment_fields');

/**=====================================================================
 *  Comment args change
=====================================================================*/
  
add_filter( 'comment_form_defaults', 'fexa_comment_form_allowed_tags' );
function fexa_comment_form_allowed_tags( $defaults ) { 
    $defaults['title_reply'] =  esc_html( 'Leave a Reply','fexa' );
	$defaults['class_submit'] = '';  
	$defaults['title_reply_before'] =  '<h3 class="team-contact-title">';
	$defaults['title_reply_after'] =  '</h3><div class="pdt15"></div>';
    $defaults['comment_notes_before'] =  ''; 
    $defaults['comment_field'] = ''; 
	$defaults['label_submit'] =  esc_html( 'Post Comment','fexa' ); 
	return $defaults;
}

 
/**=====================================================================
 * Comment form field order
=====================================================================*/
add_action( 'comment_form_after_fields', 'fexa_add_textarea' );
add_action( 'comment_form_logged_in_after', 'fexa_add_textarea' );
function fexa_add_textarea(){
    if ( class_exists( 'WooCommerce' ) ) {
        if(!is_product()){
            echo '<div class="form-group form-group--material"><label>'.esc_html('Comment','fexa').'</label><textarea id="comment" name="comment" cols="30" rows="4" class="form-control" required></textarea></div><input type="submit" value="Post Comment" class="btn base-bg btn-md"></div>';
        }
    }else{
        if(is_user_logged_in()){
            echo '<div class="com-box">';
        } 
        echo '<div class="form-group form-group--material"><label>'.esc_html('Comment','fexa').'</label><textarea id="comment" name="comment" cols="30" rows="4" class="form-control" required></textarea></div><input type="submit" value="Post Comment" class="btn base-bg btn-md"></div>';
    }
}



// banner title 
function fexa_banner_title(){ 
    global $fexa;
    $blog_bnr_ttl =  trim($fexa['bnr_ttl']);      
    $post_bnr_ttl =  trim($fexa['post_bnr_ttl']);      
    $case_bnr_ttl =  trim($fexa['case_bnr_ttl']);      
    $attorney_bnr_ttl =  trim($fexa['attorney_bnr_ttl']); 

    $post_bnr_ttl =  (''!=$post_bnr_ttl) ? $post_bnr_ttl : esc_html('News & Blog','fexa');  
    $case_bnr_ttl =  (''!=$case_bnr_ttl) ? $case_bnr_ttl : esc_html('Single Case','fexa');  
    $attorney_bnr_ttl =  (''!=$attorney_bnr_ttl) ? $attorney_bnr_ttl : esc_html('Our Attorneys','fexa'); 
    $blog_bnr_ttl =  (''!=$blog_bnr_ttl) ? $blog_bnr_ttl : esc_html('Blog','fexa'); 

    if((is_home() && is_front_page()) || is_home()){
        return esc_html($blog_bnr_ttl);
    }else if(is_single()){
        if(is_singular('tc_cases')){
            return esc_html($case_bnr_ttl);
        }else if(is_singular('tc_attorney')){
            return esc_html($attorney_bnr_ttl);
        }else{
            return esc_html($post_bnr_ttl);
        }
    } 
}




// function to display number of posts.
function fexa_getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0";
    }
    return $count;
}

// function to count views.
function fexa_setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}

/**=====================================================================
 *  nav menus
=====================================================================*/

function fexa_main_menu($style=1){  
    wp_nav_menu( [
        'theme_location'    => 'mainmenu',
        'depth'             => 3,
        'container'         => false,
        'menu_id'           => 'fexa-main-menu',
        'menu_class'        => 'menu-list',  
        'fallback_cb'       => 'fexa_default_menu' 
    ] );
}   
function fexa_mobile_menu($style=1){  
    wp_nav_menu( [
        'theme_location'    => 'mobilemenu',
        'depth'             => 5,
        'container'         => false,
        'menu_id'           => 'fexa-mobile-menu',
        'menu_class'        => 'menu-accordion',  
        'fallback_cb'       => 'fexa_default_menu' 
    ] );
}   

function fexa_left_menu(){  
    wp_nav_menu( [
        'theme_location'    => 'leftmenu',
        'depth'             => 3,
        'container'         => false,
        'menu_id'           => 'fexa-main-menu',
        'menu_class'        => 'navbar-nav' ,  
        'fallback_cb'       => 'fexa_default_menu' 
    ] ); 
}   

function fexa_copyright_menu(){  
    wp_nav_menu( [
        'theme_location'    => 'copyright',
        'depth'             => 1,
        'container'         => false,
        'menu_id'           => 'fexa-copyright',
        'menu_class'        => 'copyright' ,  
        'fallback_cb'       => 'fexa_default_menu' 
    ] ); 
}   

/**=====================================================================
 *   fallback menu 
=====================================================================*/
  
function fexa_default_menu() {
    ?>
    <ul class="menu-list"> 
        <li>
            <a href="<?php echo esc_url(admin_url('nav-menus.php')); ?>" class="nav-link"><?php esc_html_e( 'ADD MENU', 'fexa'); ?></a> 
        </li>                
    </ul>
    <?php
}  
 

/**===================================================================
 *   load more button
=====================================================================*/
function fexa_load_more(){ 
    global $wp_query; // you can remove this line if everything works for you
     
    // don't display the button if there are not enough posts
    if (  $wp_query->max_num_pages > 1 ){
        echo '<div class="text-center pdb25">
                <a id="link2" href="#" class="load-more-wave"><span class="loading-wave-animation"><span></span></span>'.esc_html('loading','fexa').'</a>
            </div>'; // you can use <a> as well
    }
}
