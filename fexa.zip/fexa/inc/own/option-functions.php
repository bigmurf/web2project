<?php 

class Fexa{
 
	public static function fexa_logo($type){ 
		global $post,$fexa;
		
		switch ($type) {
			case 'alt':
				$logo_el = (isset($fexa['logo']['alt']) && ''!=$fexa['logo']['alt']) ? $fexa['logo']['alt'] : esc_html('Fexa','fexa');
				break;
			
			default:
				$logo_el = (isset($fexa['logo']['url']) && (''!=$fexa['logo']['url'])) ? $fexa['logo']['url'] : ( FEXA_URI.'assets/images/logo.png');
				break;
		}

		if(is_page()){ 
			switch ($type) {
				case 'alt': 
					$get_image_url = get_post_meta(get_the_ID(), '_theme_core_logo_img', true); 
					$get_image_id = attachment_url_to_postid($get_image_url); 
					$logo_el = get_post_meta ( $get_image_id, '_wp_attachment_image_alt', true ); 
					break;
				
				default:
					$logo_el = (get_post_meta($post->ID,'_theme_core_logo_img',true)) ? get_post_meta($post->ID,'_theme_core_logo_img',true) : $logo_el ;
					break;
			}			
		}

		return $logo_el;		
	}
	
	public static function fexa_logo_hover($type){ 
		global $post,$fexa;
		
		switch ($type) {
			case 'alt':
				$logo_el = (isset($fexa['logo_tr']['alt']) && ''!=$fexa['logo_tr']['alt']) ? $fexa['logo_tr']['alt'] : esc_html('Fexa','fexa');
				break;
			
			default:
				$logo_el = (isset($fexa['logo_tr']['url']) && (''!=$fexa['logo_tr']['url'])) ? $fexa['logo_tr']['url'] : ( FEXA_URI.'assets/images/logo.png');
				break;
		}

		if(is_page()){ 
			switch ($type) {
				case 'alt': 
					$get_image_url = get_post_meta(get_the_ID(), '_theme_core_logo_img_tr', true); 
					$get_image_id = attachment_url_to_postid($get_image_url); 
					$logo_el = get_post_meta ( $get_image_id, '_wp_attachment_image_alt', true ); 
					break;
				
				default:
					$logo_el = (get_post_meta($post->ID,'_theme_core_logo_img_tr',true)) ? get_post_meta($post->ID,'_theme_core_logo_img_tr',true) : $logo_el ;
					break;
			}			
		}

		return $logo_el;		
	}

	public static function fexa_headers_style(){
		global $fexa;
		// return $headers = (isset($fexa['header_styles_all']) || ''!=$fexa['header_styles_all']) ? $fexa['header_styles_all'] : '1';
		return '1';
	} 
	
	public static function fexa_social_links($icon='',$target=''){ 
		global $fexa;
		$social = ''; 
		$changed = str_replace('-', '_', $icon);
		$link = $fexa[$changed];
		$target_blank = ($target=='blank') ? 'target=_blank' : '';
		if($link){
			$social = '<li><a href="'.esc_url($link).'" '.esc_attr($target_blank).'><i class="fa fa-'.esc_attr($icon).'"></i></a></li>'; 
		} 
		echo wp_kses_post($social);
	}
	public static function fexa_footer_style(){
		global $fexa;
		// return $headers = (isset($fexa['footer_styles_all']) || ''!=$fexa['footer_styles_all']) ? $fexa['footer_styles_all'] : '1';
		return '1';
	}
	public static function fexa_footer_top_border(){
		global $fexa;
		return $footer_top_border = (isset($fexa['copyright_bdr_clr']) || !empty($fexa['copyright_bdr_clr'])) ? $fexa['copyright_bdr_clr'] : '0';
	}
	public static function fexa_copyright(){ 
		global $post,$fexa; 
		$text = !empty($fexa['copyright']) ? $fexa['copyright'] : '&copy; 2019 Fexa. All rights reserved.'; 
		?> 
			<?php printf(esc_html('%s','fexa'),$text); ?>  
        <?php
	}
	public static function fexa_page_title(){
		global $fexa;
		return $headers = (isset($fexa['pag_ttl_swtch'])) ? $fexa['pag_ttl_swtch'] : '1';
	}
	
	// ==============================================================

	public static function fexa_call2_text(){
		global $fexa;
		$fexa_cal2_txt =  (''!=$fexa['cal2_text']) ? $fexa['cal2_text'] : '';
		echo esc_html($fexa_cal2_txt);
	} 
	public static function fexa_call2_btn(){
		global $fexa;
		$fexa_cal2_btntxt =  (''!=$fexa['cal2_btn']) ? $fexa['cal2_btn'] : 'Contact';
		$fexa_cal2_btnlnk =  (''!=$fexa['cal2_btn_lnk']) ? $fexa['cal2_btn_lnk'] : '#';
		echo '<a href="'.esc_url($fexa_cal2_btnlnk).'" class="call_to_action_btn">'.esc_html($fexa_cal2_btntxt).'</a>';
	}  
}