<?php 
/**
 * The template for displaying breadcrumb
 * 
 * @package Fexa
 */
 

function fexa_breadcrumbs() {
  $home_breadcrumbs = 0; // put 1 to show breadcrumbs on home page, otherwise leave it as it is
  $separator = ''; // separator
  $home = 'Home'; // home text
  $mycurrent = 1; //put 1 to show current post/page title in breadcrumbs, otherwise leave put 0
  global $post;
  $myhome_url = esc_url(home_url('/'));
  if (is_home() || is_front_page()) {
    if ($home_breadcrumbs == 1) echo '<ol class="breadcrumb"><li class="breadcrumb-item"><a href="' . esc_url($myhome_url) . '">' . esc_html($home) . '</a></li></ol>';
  } else {
    echo '<ol class="breadcrumb"><li class="breadcrumb-item"><a href="' . esc_url($myhome_url) . '">' . esc_html($home) . '</a></li>';
    if ( is_category() ) {
      $thisCat = get_category(get_query_var('cat'), false);
      if ($thisCat->parent != 0) echo get_category_parents($thisCat->parent, TRUE, ' ');
      echo '<li class="breadcrumb-item active">' . single_cat_title('', false) .  '</li>';
    } elseif ( is_search() ) {
      echo '<li class="breadcrumb-item active">' . get_search_query() .  '</li>';
    } elseif ( is_day() ) {
      echo '<li class="breadcrumb-item"><a href="' . esc_url(get_year_link(get_the_time('Y'))) . '">' . get_the_time('Y') . '</a></li> ' ;
      echo '<li class="breadcrumb-item"><a href="' . esc_url(get_month_link(get_the_time('Y'),get_the_time('m'))) . '">' . get_the_time('F') . '</a></li>';
      echo '<li class="breadcrumb-item active">' . get_the_time('d') . '</li>';
    } elseif ( is_month() ) {
      echo '<li class="breadcrumb-item"><a href="' . esc_url(get_year_link(get_the_time('Y'))) . '">' . get_the_time('Y') . '</a></li>';
      echo '<li class="breadcrumb-item active">' . get_the_time('F') . '</li>';
    } elseif ( is_year() ) {
      echo '<li class="breadcrumb-item active">' . get_the_time('Y') . '</li>';
    } elseif ( is_single() && !is_attachment() ) {
      if ( get_post_type() != 'post' ) {
        $post_type = get_post_type_object(get_post_type());
        $slug = $post_type->rewrite;
        echo '<li class="breadcrumb-item"><a href="' . esc_url($myhome_url) . '/' . $slug['slug'] . '/">' . $post_type->labels->singular_name . '</a></li>';
        if ($mycurrent == 1) echo  '<li class="breadcrumb-item active">' . get_the_title() . '</li>';
      } else {
        $cat = get_the_category(); $cat = $cat[0];
        $cats = get_category_parents($cat, TRUE, ' ');
        if ($mycurrent == 0) $cats = 'preg_replace("#^(.+)\s$separator\s$#", "$1", $cats)';
        echo '<li class="breadcrumb-item">'.$cats.'</li>';
        if ($mycurrent == 1) echo '<li class="breadcrumb-item active">' . get_the_title() . '</li>';
      }
    } elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
      $post_type = get_post_type_object(get_post_type());
      echo '<li class="breadcrumb-item active">' . $post_type->labels->singular_name . '</li>';
    } elseif ( is_attachment() ) {
      $parent = get_post($post->post_parent);
      $cat = get_the_category($parent->ID); $cat = $cat[0];
      echo get_category_parents($cat, TRUE, ' ');
      echo '<li class="breadcrumb-item"><a href="' . esc_url(get_permalink($parent)) . '">' . $parent->post_title . '</a></li>';
      if ($mycurrent == 1) echo   '<li class="breadcrumb-item active">' . get_the_title() . '</li>';
    } elseif ( is_page() && !$post->post_parent ) {
      if ($mycurrent == 1) echo '<li class="breadcrumb-item active">' . get_the_title() . '</li>';
    } elseif ( is_page() && $post->post_parent ) {
      $parent_id  = $post->post_parent;
      $breadcrumbs = array();
      while ($parent_id) {
        $page = get_page($parent_id);
        $breadcrumbs[] = '<li class="breadcrumb-item"><a href="' . esc_url(get_permalink($page->ID)) . '">' . get_the_title($page->ID) . '</a></li>';
        $parent_id  = $page->post_parent;
      }
      $breadcrumbs = array_reverse($breadcrumbs);
      for ($i = 0; $i < count($breadcrumbs); $i++) {
        echo wp_kses_post($breadcrumbs[$i]); 
      }
      if ($mycurrent == 1) echo '<li class="breadcrumb-item active">' . get_the_title() . '</li>';
    } elseif ( is_tag() ) {
      echo '<li class="breadcrumb-item active">' . single_tag_title('', false) .  '</li>';
    } elseif ( is_author() ) {
       global $author;
      $userdata = get_userdata($author);
      echo '<li class="breadcrumb-item active">' . $userdata->display_name . '</li>';
    } elseif ( is_404() ) {
      echo '<li class="breadcrumb-item active">' . '404' . '</li>';
    }
    if ( get_query_var('paged') ) {
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ){
      	echo '<li class="breadcrumb-item active">' . get_query_var('paged') . '</li>';
      }  
    }
    echo '</ol>';
  }
}