<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fexa
 */

get_header(); ?>
<div class="main-content section-padding">
  <div class="container">
    <div class="row">
      <?php if(!is_active_sidebar('sidebar-1')){
        $col = '12';
      }else{
        $col = '8';
      } ?>
      <div class="col-md-12 col-lg-<?php echo esc_attr($col); ?>">
      <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/privacy-policy"><i class="fa fa-home"></i> Privacy Policy</a></li>
      <li class="breadcrumb-item active" aria-current="page">Cookie Policy</li>
      </ol>
      </nav>
        <?php 
          /* Start the Loop */
          while ( have_posts() ) : the_post(); 
            get_template_part( 'template-parts/content','page' );   
          endwhile; 
        ?>  
        <!--/.blog-post2-->
        <div class="text-center mb20 fexa-pagination">
          <?php fexa_pagination(); ?> 
        </div>
      </div>
      <?php if(is_active_sidebar('sidebar-1')): ?>
        <div class="col-md-12 col-lg-4">
          <aside class="sidebar">
            <?php get_sidebar(); ?>
          </aside>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php get_footer();
