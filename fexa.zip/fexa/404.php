<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_anesc_htmle_error_404_Page
 *
 * @package Fexa
 */

get_header();
?>
 
    <div class="container">
      <div class="error-outer-wrapper">
        <div class="error-innter-content text-center">
          <img src="<?php echo FEXA_URI; ?>assets/images/404.png" alt="<?php echo esc_attr('not found','fexa'); ?>">
          <h2 class="base-color error-title"><?php esc_html_e('Page not found!','fexa'); ?></h2>
          <p class="error-description">
            <?php $fexa_str = __('Were sorry, the page you have looked for does not exist ! <br/>Please go to home or use a search?','fexa');
            echo wp_kses_post($fexa_str); ?>
          </p>
          <form method="get" class="error-search-form" action="<?php echo esc_url(home_url('/')); ?>">  
            <input type="text"  class="form-control" placeholder="<?php esc_attr_e( 'Search...', 'fexa' ); ?>" value="<?php echo get_search_query(); ?>" name="s"> 
            <button type="submit" class="submit-button"><i class="fa fa-search"></i> </button>
          </form>
        </div>
      </div>
    </div>

<?php
get_footer();
 