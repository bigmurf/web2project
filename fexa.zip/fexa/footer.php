<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Fexa
 */

if(is_page()){
    global $post; 
    $ftr = get_post_meta($post->ID,'_theme_core_footer_style',true);
    $fexa_footer = ($ftr) ? $ftr : Fexa::fexa_footer_style();
    $ftbdr = get_post_meta($post->ID,'_theme_core_footer_top_border',true);
    $fexa_footer_top_border = (isset($ftbdr)) ? $ftbdr : Fexa::fexa_footer_top_border();
}else{
    $fexa_footer = Fexa::fexa_footer_style();
    $fexa_footer_top_border = Fexa::fexa_footer_top_border();
}
get_template_part('footers/footer',$fexa_footer);

?>
 

<?php wp_footer(); ?>

</body>
</html>
