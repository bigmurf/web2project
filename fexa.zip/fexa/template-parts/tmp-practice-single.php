<?php
/**
 * Template Name: Practice Area
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fexa
 */

get_header(); ?>
<div class="main-content section-padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-lg-8">
        <?php 
          /* Start the Loop */
          while ( have_posts() ) : the_post(); 
            get_template_part( 'template-parts/content','practice' );   
          endwhile; 
        ?>  
        <!--/.blog-post2-->
        <div class="text-center mb20 fexa-pagination">
          <?php fexa_pagination(); ?> 
        </div>
      </div>
      <div class="col-md-12 col-lg-4">
        <aside class="sidebar">
          <?php dynamic_sidebar( 'sidebar-practice' );  ?>
        </aside>
      </div>
    </div>
  </div>
</div>
<?php get_footer();
