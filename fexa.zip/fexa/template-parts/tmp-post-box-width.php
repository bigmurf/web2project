<?php
/**
 * Template Name: Post Box Width
 * Template Post Type: post
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Fexa
 */ 
get_header(); ?>
<div class="main-content section-padding">
  <div class="container pdt10">
    <div class="row"> 
      <div class="col-lg-12 col-md-12">
		<?php while ( have_posts() ) : the_post();
			get_template_part( 'template-parts/content', 'single' );
		endwhile; ?>
      </div>
    </div>
  </div>
</div>
<?php 
get_footer();