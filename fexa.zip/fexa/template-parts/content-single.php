
<div class="blog-post2">
	<?php if(has_post_thumbnail()): ?>
		<?php $image_src = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'fexa-blog-post'); 
		$image_url = $image_src[0];
		$image_alt = get_post_meta(get_the_ID(), '_wp_attachment_image_alt', true);
		?>
		<div class="blog-post2__image">
			<img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($image_alt); ?>" />
		</div>
	<?php endif; ?>   
  <div class="blog-post2__text-content">
    <div class="blog-post2__meta small">
      <span class="blog-post2__date letter-spacing"><i class="fa fa-clock-o"></i> <?php fexa_posted_on(); ?></span>
      <span class="blog-post2__category-wrap">
      <span class="title pdr10 "><?php esc_html_e('In','fexa'); ?></span>
      <?php  
        $jab_terms = get_the_terms( get_the_ID(), 'category' );  
        $jab_link = array(); 
        $jab_link_url = array(); 
        $i=1;
        foreach ( $jab_terms as $jab_term ) { 
          if($i>3) break;
          $jab_link_url[] = '<a href="'.esc_url(home_url('/').'category/'.$jab_term->slug).'/"  class="base-color blog-post2__category letter-spacing ">'.esc_html($jab_term->name).'</a>'; 
          $i++;
        }               
        $jab_links_ttl = join( ", ", $jab_link_url );  
        echo wp_kses_post($jab_links_ttl);
        ?> 
      </span>
    </div>
    <h3 class="blog-post2__title"><a href="javascript:void();"><?php the_title(); ?></a></h3> 
    <?php the_content();
        wp_link_pages( array(
            'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'fexa' ),
            'after'       => '</div>',
            'link_before' => '<span class="page-number">',
            'link_after'  => '</span>',
        ) ); 
    ?> 
  </div>
  <?php if(has_tag() || class_exists('TC')): ?>
    <div class="d-flex align-items-center justify-content-between fexa-post-tags">
      <div class="tag-cloud pdt5">
  		<?php the_tags( '', '', '' ); ?> 
      </div>
      <div class="share-area">
      	<?php do_action('fexa_post_share'); ?>
      </div>
    </div>
  <?php endif; ?>
</div>
<!--/.blog-post2-->
      
<?php $author_desc = get_the_author_meta( 'description' ); ?>
<?php if($author_desc): ?>
<div class="author-info author-info-border ">
  <?php $xara_avatar = get_avatar( get_the_author_meta( 'ID' ), 100 ); ?>
  <?php if($xara_avatar): ?> 
    <div class="author-info__photo">
      <?php echo get_avatar( get_the_author_meta( 'ID' ), 100 ); ?>
    </div>
  <?php endif; ?>
  <div class="author-info__text-content">
    <h4 class="author-info__name"><?php the_author(); ?></h4><span class="author-info__designation"><?php the_author_meta( 'designation' ); ?></span>
    <p><?php the_author_meta( 'description' ); ?></p>
  </div>
  <div class="clear"></div>
</div>
<?php endif; ?> 

<?php 
	// If comments are open or we have at least one comment, load up the comment template.
	if ( comments_open() || get_comments_number() ) :
		comments_template();
endif;
?>   