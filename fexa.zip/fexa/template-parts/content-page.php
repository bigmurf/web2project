<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fexa
 */  
$fexa_page_title_on = Fexa::fexa_page_title();
?>

<div id="post-<?php the_ID(); ?>" <?php post_class('practice-details-wrapper'); ?>>
   <?php fexa_post_thumbnail(); ?>
	<?php if($fexa_page_title_on!=0 ): ?> 
		<h2 class="<?php echo (has_post_thumbnail() ? 'pdt40' : 'mtm10' ); ?> pdb10"><?php the_title(); ?></h2>		 
	<?php endif; ?> 
  <div class="team-detail-bottom pdt0">
	<?php
	the_content(); 
	wp_link_pages( array(
		'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'fexa' ),
		'after'  => '</div>',
	) );
	?> 
  </div>
  <?php 
	// If comments are open or we have at least one comment, load up the comment template.
	if ( comments_open() || get_comments_number() ) :
			comments_template();
	endif;
	?>  
</div>
 