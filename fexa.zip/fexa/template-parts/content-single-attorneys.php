<?php 
$designation = get_post_meta(get_the_ID(),'_theme_core_designation',true);
$practice_area = get_post_meta(get_the_ID(),'_theme_core_practice_area',true); 
$contact = get_post_meta(get_the_ID(),'_theme_core_contact',true); 
$facebook = get_post_meta(get_the_ID(),'_theme_core_facebook',true); 
$twitter = get_post_meta(get_the_ID(),'_theme_core_twitter',true); 
$google_plus = get_post_meta(get_the_ID(),'_theme_core_google_plus',true); 
$linkedin = get_post_meta(get_the_ID(),'_theme_core_linkedin',true); 
$email = get_post_meta(get_the_ID(),'_theme_core_email',true);  
?>
    <div class="team-detail-wrapper">
      <div class="team-detail">
        <?php if(has_post_thumbnail()): ?>
          <div class="team-detail__image">
            <?php the_post_thumbnail(); ?>
          </div>
        <?php endif; ?>
        <div class="team-detail__text-content">
          <h3 class="team-detail__name"><?php the_title(); ?></h3>
          <p class="team_details__designation"><?php echo esc_html($designation); ?></p>
          <h4><?php esc_html_e('Practice Area','fexa'); ?></h4>
          <?php echo '<p>'.wp_kses_post($practice_area).'</p>'; ?> 
          <h4><?php esc_html_e('Contact','fexa'); ?></h4>
          <?php echo '<p>'.wp_kses_post($contact).'</p>'; ?>  
          <ul class="social-icons">
            <?php if($facebook): ?>
              <li><a href="<?php echo esc_url($facebook); ?>"><i class="fa fa-facebook"></i></a></li>
            <?php endif; ?>
            <?php if($twitter): ?>
              <li><a href="<?php echo esc_url($twitter); ?>"><i class="fa fa-twitter"></i></a></li>
            <?php endif; ?>
            <?php if($google_plus): ?>
              <li><a href="<?php echo esc_url($google_plus); ?>"><i class="fa fa-google-plus"></i></a></li>
            <?php endif; ?>
            <?php if($linkedin): ?>
              <li><a href="<?php echo esc_url($linkedin); ?>"><i class="fa fa-linkedin"></i></a></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
      <div class="team-detail-bottom">
       <?php the_content(); ?>
        <hr>
      </div>
      <form id="attoryneyemail" class="mt40 pdt20 pdb20" action="#" method="POST">
        <h3 class="team-contact-title"><?php esc_html_e('Contact Me','fexa'); ?></h3>
        <div class="pdt40"></div>
        <input name="sentto" class="sentto" type="hidden" value="<?php echo esc_attr($email); ?>">
        <div class="form-group form-group--material">
          <label><?php esc_html_e('Name','fexa'); ?></label>
          <input name="name" id="name" type="text" class="form-control">
        </div>
        <div class="form-group form-group--material">
          <label><?php esc_html_e('Email','fexa'); ?></label>
          <input name="email" id="email" type="email" class="form-control">
        </div>
        <div class="form-group form-group--material">
          <label><?php esc_html_e('Phone','fexa'); ?></label>
          <input name="phone" id="phone" type="text" class="form-control">
        </div>
        <div class="form-group form-group--material">
          <label><?php esc_html_e('Details','fexa'); ?></label>
          <textarea name="message" id="message" class="form-control"></textarea>
        </div>
        <input type="submit" value="<?php esc_attr_e('Send Message','fexa'); ?>" class="btn base-bg btn-md">
      </form>
    </div>