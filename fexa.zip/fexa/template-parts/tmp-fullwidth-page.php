<?php
/**
 * Template Name: Page Full Width 
 *
 * @package Fexa
 */

get_header();
?>
    <div class="fexa-ful"> 	
		<?php 
			/* Start the Loop */
			while ( have_posts() ) : the_post(); 
				the_content();
			endwhile; 
		?>  
	</div> 
<?php get_footer();
