<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fexa
 */

?> 

<div id="post-<?php the_ID(); ?>" class="col-md-6 col-sm-6 col-xs-6 col-xxs-12"> 
    <div class="blog-post">
        <div class="blog-post__image-wrap">
            <?php if(has_post_thumbnail()): ?>
                <?php $image_src = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),''); 
                    $image_url = $image_src[0];
                    $image_alt = get_post_meta(get_the_ID(), '_wp_attachment_image_alt', true);
                ?>
                <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($image_alt); ?>">
                <div class="post-date">
                    <span class="date"><?php the_time('d'); ?></span>
                    <span class="month"><?php the_time('M'); ?></span>
                </div>
            <?php endif; ?> 
        </div>
        <div class="blog-post__text-content <?php echo (!has_post_thumbnail()) ? 'm0 mtm25 ' : ''; ?>">
            <h3 class="blog-post__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            <?php the_excerpt(); ?>
            <a href="<?php the_permalink(); ?>" class="blog-post__read-more"><?php esc_html_e('Read More','fexa'); ?></a>
        </div>
    </div><!--/.blog-post-->
</div>