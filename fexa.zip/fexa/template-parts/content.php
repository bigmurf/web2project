<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fexa
 */
?>

<div id="post-<?php the_ID(); ?>" class="blog-post2 <?php echo (has_post_thumbnail()) ? '' : 'noimg'; ?>"> 
    <?php $blog_noimg = 'blog_noimg';
        if(has_post_thumbnail()):
        $blog_noimg = '';
        $image_src = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'fexa-blog-post'); 
        $image_url = $image_src[0];
        $image_alt = get_post_meta(get_the_ID(), '_wp_attachment_image_alt', true);
        ?>
        <div class="blog-post2__image">
            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($image_alt); ?>">
        </div> 
    <?php endif; ?>
  <div class="blog-post2__text-content  <?php echo esc_attr($blog_noimg); ?>">
    <div class="blog-post2__meta small">
      <span class="blog-post2__date letter-spacing"><i class="fa fa-clock-o"></i> <?php fexa_posted_on(); ?></span>
      <span class="blog-post2__category-wrap">
      <span class="title pdr10 "><?php esc_html_e('In','fexa'); ?></span>
        <?php  
            $fexa_terms = get_terms( 'category' , array( 'hide_empty' => 1 ) );
            $i=0;
            if ( ! empty( $fexa_terms ) && ! is_wp_error( $fexa_terms ) ){ 
                foreach ( $fexa_terms as $fexa_term ) {
                    if($i>1) break;
                    if($i>0) echo ', '; 
                    echo '<a href="' . esc_url(get_term_link( $fexa_term )) . '" class="base-color blog-post2__category letter-spacing ">' . esc_html($fexa_term->name) . '</a>'; 
                    $i++;
                } 
            } 
        ?>
      
      </span>
    </div>
    <h3 class="blog-post2__title">
        <?php if(is_sticky()): ?>
            <i class="fa fa-thumb-tack"></i>
        <?php endif; ?> 
        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
    </h3>
    <p class=""><?php the_excerpt(); ?></p>
    <a href="<?php the_permalink(); ?>" class="blog-post__read-more letter-spacing"><?php esc_html_e('READ MORE','fexa'); ?></a>
  </div>
</div>