<?php
/**
 * The template for displaying all single attorneys
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Fexa
 */ 
get_header(); ?>
    <div class="main-container section-padding">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-4">
            <aside class="sidebar sidebar--left">
              <?php dynamic_sidebar( 'sidebar-attorney' ); ?> 
            </aside>
          </div>
          <div class="col-lg-8 col-md-12">
            <?php while ( have_posts() ) : the_post();
              get_template_part( 'template-parts/content', 'single-attorneys' );
            endwhile; ?>
          </div>
        </div>
      </div>
    </div>
<?php 
get_footer();
